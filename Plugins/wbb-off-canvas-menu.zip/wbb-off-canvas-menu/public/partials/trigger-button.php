<div class="wbb-ocm-trigger <?php echo ( get_theme_mod( "wbb_ocm_trigger_side", true ) !== "" ? get_theme_mod( "wbb_ocm_trigger_side", true ) : "left" ); ?>">
    <img src="<?php echo $trigger_icon ?>">
</div>