<?php
/**
 * Template for displaying no-items in maps-list table
 */

?>
<tr>
	<td colspan="5"><?php _e( 'No items', 'hugeit_maps' ); ?></td>
</tr>
