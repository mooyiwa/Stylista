<?php get_header(); 

?>
	<div id="container">
		<div id="content">
                <?php echo do_shortcode('[carousel-horizontal-posts-content-slider]'); ?>
         
		</div><!-- #content -->
                <div id="debug">
                <?php echo do_shortcode("[huge_it_maps id='1']"); ?>  
   
		</div><!-- #content -->
	</div><!-- #container -->


 
<?php get_footer(); ?>